$(document).ready(function() {
    $('.data-header').click(function() {
        $(this.nextElementSibling).toggle()
    });
});