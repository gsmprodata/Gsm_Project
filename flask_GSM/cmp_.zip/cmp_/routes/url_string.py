class filters:
    controller = "/filter"
    class action:
        getprocessorbrands = "/getProcessorBrands"
        getprocessorbybrand = "/getProcessorByBrand"
        getfilterdevice = "/getFilterDevice"
        getmorefilterdevice = "/getmorefilterdevice"